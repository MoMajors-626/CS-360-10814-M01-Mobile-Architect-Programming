package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class GridActivity extends AppCompatActivity
        implements InventoryAdapter.InventoryActionListener {
    // Gives the inventory screen access to the Warehouse Hero database.
    private Database database;
    // Controls the list of inventory items shown on the screen.
    private RecyclerView recyclerView;
    private InventoryAdapter inventoryAdapter;
    private ArrayList<InventoryItem> inventoryItems;
    // Buttons used to add items and open the navigation menu.
    private MaterialButton addItemButton;
    private ImageView menuButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Allows the screen to use the full display area.
        EdgeToEdge.enable(this);
        // Loads the layout used for the inventory screen.
        setContentView(R.layout.activity_grid);
        // Connects this screen to the SQLite database.
        database = new Database(this);
        // Connects the Java variables to the views in activity_grid.xml.
        recyclerView = findViewById(R.id.recyclerView);
        addItemButton = findViewById(R.id.btnadditem);
        menuButton = findViewById(R.id.imageView);
        // Creates the list that will hold the inventory items.
        inventoryItems = new ArrayList<>();
        // Connects the inventory list to the adapter.
        inventoryAdapter = new InventoryAdapter(
                inventoryItems,
                this
        );
        // Displays the inventory items in a vertical list.
        recyclerView.setLayoutManager(
                new LinearLayoutManager(this)
        );

        recyclerView.setAdapter(inventoryAdapter);
        // Opens the Add Item dialog when the user selects the button.
        addItemButton.setOnClickListener(
                view -> showAddItemDialog()
        );
        // Opens the navigation menu when the menu icon is selected.
        menuButton.setOnClickListener(
                view -> showNavigationMenu()
        );
        // Adds padding so the screen does not overlap Android system bars.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (view, windowInsets) -> {

                    Insets systemBars = windowInsets.getInsets(
                            WindowInsetsCompat.Type.systemBars()
                    );

                    view.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return windowInsets;
                }
        );
        // Loads the saved inventory items when the screen opens.
        loadInventory();
    }

    @Override
    protected void onResume() {
        super.onResume();

        //Reloads the inventory when the user returns to this screen.
        //This makes sure the list shows the latest database information.
        if (database != null && inventoryAdapter != null) {
            loadInventory();
        }
    }
    // Reads the saved inventory items and refreshes the displayed list.
    private void loadInventory() {

        ArrayList<InventoryItem> updatedItems =
                database.getAllItems();

        inventoryAdapter.replaceItems(updatedItems);
    }

     //Creates the form used by both the Add Item and Edit Item dialogs.
     //This avoids creating the same input fields in two different places.
    private LinearLayout createItemForm(
            EditText nameInput,
            EditText quantityInput
    ) {

        LinearLayout formLayout =
                new LinearLayout(this);
        // Places the item name and quantity fields on separate lines.
        formLayout.setOrientation(
                LinearLayout.VERTICAL
        );
        //Converts the padding value into pixels so the dialog
        //displays correctly on different screen densities.
        int padding = (int) (
                24 * getResources()
                        .getDisplayMetrics()
                        .density
        );

        formLayout.setPadding(
                padding,
                padding / 2,
                padding,
                0
        );
        // Sets up the input field used for the inventory item name.
        nameInput.setHint("Item name");
        nameInput.setSingleLine(true);
        // Sets up the quantity field to accept numbers.
        quantityInput.setHint("Quantity");
        quantityInput.setSingleLine(true);
        quantityInput.setInputType(
                InputType.TYPE_CLASS_NUMBER
        );
        // Adds both input fields to the dialog form.
        formLayout.addView(nameInput);
        formLayout.addView(quantityInput);

        return formLayout;
    }
    // Opens a dialog that allows the user to add a new inventory item.
    private void showAddItemDialog() {

        EditText nameInput =
                new EditText(this);

        EditText quantityInput =
                new EditText(this);
        // Builds the form using the name and quantity fields.
        LinearLayout formLayout =
                createItemForm(
                        nameInput,
                        quantityInput
                );
        // Creates the Add Inventory Item dialog.
        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("Add Inventory Item")
                        .setMessage(
                                "Enter the item name and quantity."
                        )
                        .setView(formLayout)
                        .setNegativeButton(
                                "Cancel",
                                null
                        )
                        .setPositiveButton(
                                "Add",
                                null
                        )
                        .create();
        //Uses a custom click listener so the dialog stays open
        //when the user enters invalid information.
        dialog.setOnShowListener(unused -> {

            dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
            ).setOnClickListener(view -> {
                // Gets the item information entered by the user.
                String itemName = nameInput
                        .getText()
                        .toString()
                        .trim();

                String quantityText = quantityInput
                        .getText()
                        .toString()
                        .trim();
                // Prevents the user from saving an item with empty fields.
                if (
                        itemName.isEmpty()
                                || quantityText.isEmpty()
                ) {

                    Toast.makeText(
                            GridActivity.this,
                            "Enter an item name and quantity.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                int quantity;
                //Attempts to convert the entered quantity into a number.
                //The item will not be added if the value is invalid.
                try {
                    quantity =
                            Integer.parseInt(quantityText);
                } catch (NumberFormatException exception) {

                    Toast.makeText(
                            GridActivity.this,
                            "Quantity must be a number.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }
                // Attempts to save the new inventory item to SQLite.
                boolean itemAdded =
                        database.addItem(
                                itemName,
                                quantity
                        );

                if (itemAdded) {

                    Toast.makeText(
                            GridActivity.this,
                            "Item added.",
                            Toast.LENGTH_SHORT
                    ).show();
                    // Refreshes the list and closes the dialog.
                    loadInventory();
                    dialog.dismiss();

                } else {

                    Toast.makeText(
                            GridActivity.this,
                            "Unable to add item.",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });
        });

        dialog.show();
    }

    @Override
    public void onEditItem(InventoryItem item) {

        EditText nameInput =
                new EditText(this);

        EditText quantityInput =
                new EditText(this);

        nameInput.setText(item.getName());

        quantityInput.setText(
                String.valueOf(item.getQuantity())
        );

        LinearLayout formLayout =
                createItemForm(
                        nameInput,
                        quantityInput
                );

        AlertDialog dialog =
                new AlertDialog.Builder(this)
                        .setTitle("Edit Inventory Item")
                        .setView(formLayout)
                        .setNegativeButton(
                                "Cancel",
                                null
                        )
                        .setPositiveButton(
                                "Save",
                                null
                        )
                        .create();

        dialog.setOnShowListener(unused -> {

            dialog.getButton(
                    AlertDialog.BUTTON_POSITIVE
            ).setOnClickListener(view -> {

                String updatedName = nameInput
                        .getText()
                        .toString()
                        .trim();

                String quantityText = quantityInput
                        .getText()
                        .toString()
                        .trim();

                if (
                        updatedName.isEmpty()
                                || quantityText.isEmpty()
                ) {

                    Toast.makeText(
                            GridActivity.this,
                            "Enter an item name and quantity.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                int updatedQuantity;

                try {
                    updatedQuantity =
                            Integer.parseInt(quantityText);
                } catch (NumberFormatException exception) {

                    Toast.makeText(
                            GridActivity.this,
                            "Quantity must be a number.",
                            Toast.LENGTH_SHORT
                    ).show();

                    return;
                }

                boolean itemUpdated =
                        database.updateItem(
                                item.getId(),
                                updatedName,
                                updatedQuantity
                        );

                if (itemUpdated) {

                    Toast.makeText(
                            GridActivity.this,
                            "Item updated.",
                            Toast.LENGTH_SHORT
                    ).show();

                    loadInventory();
                    dialog.dismiss();

                } else {

                    Toast.makeText(
                            GridActivity.this,
                            "Unable to update item.",
                            Toast.LENGTH_SHORT
                    ).show();
                }
            });
        });

        dialog.show();
    }

    @Override
    public void onDeleteItem(InventoryItem item) {

        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage(
                        "Delete " + item.getName() + "?"
                )
                .setNegativeButton(
                        "Cancel",
                        null
                )
                .setPositiveButton(
                        "Delete",
                        (dialog, selectedButton) -> {

                            boolean itemDeleted =
                                    database.deleteItem(
                                            item.getId()
                                    );

                            if (itemDeleted) {

                                Toast.makeText(
                                        GridActivity.this,
                                        "Item deleted.",
                                        Toast.LENGTH_SHORT
                                ).show();

                                loadInventory();

                            } else {

                                Toast.makeText(
                                        GridActivity.this,
                                        "Unable to delete item.",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                )
                .show();
    }

    private void showNavigationMenu() {

        PopupMenu menu =
                new PopupMenu(this, menuButton);

        menu.getMenu().add(
                0,
                1,
                0,
                "Inventory"
        );

        menu.getMenu().add(
                0,
                2,
                1,
                "Notifications"
        );

        menu.getMenu().add(
                0,
                3,
                2,
                "Log Out"
        );

        menu.setOnMenuItemClickListener(item -> {

            if (item.getItemId() == 1) {

                return true;

            } else if (item.getItemId() == 2) {

                Intent notificationIntent =
                        new Intent(
                                GridActivity.this,
                                NotificationsActivity.class
                        );

                startActivity(notificationIntent);
                return true;

            } else if (item.getItemId() == 3) {

                Intent loginIntent =
                        new Intent(
                                GridActivity.this,
                                LoginActivity.class
                        );

                loginIntent.setFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK
                );

                startActivity(loginIntent);
                return true;
            }

            return false;
        });

        menu.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (database != null) {
            database.close();
        }
    }
}