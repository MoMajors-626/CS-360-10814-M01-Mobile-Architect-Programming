package com.example.project2;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.material.switchmaterial.SwitchMaterial;

public class NotificationsActivity extends AppCompatActivity {

    private ImageView menuButton;
    private SwitchMaterial smsSwitch;
    private TextView statusText;
    private TextView helpText;

    private SharedPreferences preferences;

    private static final String PREFS_NAME =
            "warehouse_hero_preferences";

    private static final String SMS_ENABLED_KEY =
            "sms_notifications_enabled";


    //Receives the result of Android's SMS permission request.
    private final ActivityResultLauncher<String> smsPermissionLauncher =
            registerForActivityResult(
                    new ActivityResultContracts.RequestPermission(),
                    permissionGranted -> {

                        if (permissionGranted) {

                            saveSmsPreference(true);

                            smsSwitch.setChecked(true);

                            updateStatusDisplay(true);

                            Toast.makeText(
                                    NotificationsActivity.this,
                                    "SMS notifications enabled.",
                                    Toast.LENGTH_SHORT
                            ).show();

                        } else {

                            saveSmsPreference(false);

                            smsSwitch.setChecked(false);

                            updateStatusDisplay(false);

                            Toast.makeText(
                                    NotificationsActivity.this,
                                    "SMS permission denied. Inventory will still work normally.",
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    }
            );

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        //The XML file is named notifications_screen.xml.
        setContentView(R.layout.notifications_screen);

        // Connect Java variables to XML views.
        menuButton = findViewById(R.id.imageView);
        smsSwitch = findViewById(R.id.enablesms);
        statusText = findViewById(R.id.textView8);
        helpText = findViewById(R.id.permissionHelp);

        // Open Warehouse Hero preferences.
        preferences = getSharedPreferences(
                PREFS_NAME,
                Context.MODE_PRIVATE
        );

        //Restore the user's saved notification preference.
        boolean smsEnabled = preferences.getBoolean(
                SMS_ENABLED_KEY,
                false
        );


        //Check whether Android granted SMS permission.
        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        //SMS alerts are enabled only if the user enabled
        //the feature and Android granted permission.
        boolean featureEnabled =
                smsEnabled && permissionGranted;

        smsSwitch.setChecked(featureEnabled);

        updateStatusDisplay(featureEnabled);

        //Respond when the user changes the SMS switch.
        smsSwitch.setOnCheckedChangeListener(
                (buttonView, isChecked) -> {

                    if (isChecked) {

                        enableSmsNotifications();

                    } else {

                        disableSmsNotifications();
                    }
                }
        );

        //Open the navigation menu.
        menuButton.setOnClickListener(
                view -> showNavigationMenu()
        );
    }


    //Enable SMS alerts or request permission.
    private void enableSmsNotifications() {

        boolean permissionGranted =
                ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.SEND_SMS
                ) == PackageManager.PERMISSION_GRANTED;

        if (permissionGranted) {

            saveSmsPreference(true);

            updateStatusDisplay(true);

            Toast.makeText(
                    this,
                    "SMS notifications enabled.",
                    Toast.LENGTH_SHORT
            ).show();

        } else {

             //Do not save the feature as enabled until
             //Android grants permission.
            saveSmsPreference(false);

            smsPermissionLauncher.launch(
                    Manifest.permission.SEND_SMS
            );
        }
    }


    //Disable SMS alerts inside Warehouse Hero.
    private void disableSmsNotifications() {

        saveSmsPreference(false);

        updateStatusDisplay(false);

        Toast.makeText(
                this,
                "SMS notifications disabled.",
                Toast.LENGTH_SHORT
        ).show();
    }

    //save the user's notification preference.
    private void saveSmsPreference(boolean enabled) {

        preferences.edit()
                .putBoolean(
                        SMS_ENABLED_KEY,
                        enabled
                )
                .apply();
    }

    //Update the notification status displayed on the screen.
    private void updateStatusDisplay(boolean enabled) {

        if (enabled) {

            statusText.setText(
                    "SMS notifications enabled"
            );

            helpText.setText(
                    "Warehouse Hero will send alerts when inventory is running low."
            );

        } else {

            statusText.setText(
                    "SMS notifications disabled"
            );

            helpText.setText(
                    "Use the switch above to enable low inventory SMS alerts."
            );
        }
    }

    /*
     * Display the navigation dropdown menu.
     */
    private void showNavigationMenu() {

        PopupMenu menu =
                new PopupMenu(
                        this,
                        menuButton
                );

        menu.getMenu().add(
                0,
                1,
                0,
                "Inventory"
        );

        menu.getMenu().add(
                0,
                2,
                1,
                "Notifications"
        );

        menu.getMenu().add(
                0,
                3,
                2,
                "Log Out"
        );

        menu.setOnMenuItemClickListener(item -> {

            //Open Inventory.
            if (item.getItemId() == 1) {

                Intent inventoryIntent =
                        new Intent(
                                NotificationsActivity.this,
                                GridActivity.class
                        );

                startActivity(inventoryIntent);

                finish();

                return true;
            }


            //the user is already on Notifications.

            if (item.getItemId() == 2) {

                return true;
            }


            //Log out and clear the activity history.
            if (item.getItemId() == 3) {

                Intent loginIntent =
                        new Intent(
                                NotificationsActivity.this,
                                LoginActivity.class
                        );

                loginIntent.setFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK
                                | Intent.FLAG_ACTIVITY_CLEAR_TASK
                );

                startActivity(loginIntent);

                return true;
            }

            return false;
        });

        menu.show();
    }
}