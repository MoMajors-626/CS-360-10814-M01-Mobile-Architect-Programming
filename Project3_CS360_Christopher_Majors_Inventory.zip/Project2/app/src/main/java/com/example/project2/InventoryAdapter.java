package com.example.project2;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;
// Connects the inventory data to the RecyclerView displayed on the screen.
public class InventoryAdapter
        extends RecyclerView.Adapter<InventoryAdapter.InventoryViewHolder> {
    // Defines the actions that can be performed on an inventory item.
    public interface InventoryActionListener {
        // Calls the edit method when the user wants to change an item.
        void onEditItem(InventoryItem item);
        // Calls the delete method when the user wants to remove an item.
        void onDeleteItem(InventoryItem item);
    }
    // Stores the inventory items displayed in the list.
    private final ArrayList<InventoryItem> inventoryItems;
    // Connects the adapter to the methods that handle editing and deleting.
    private final InventoryActionListener actionListener;
    // Receives the inventory list and the listener from GridActivity.
    public InventoryAdapter(
            ArrayList<InventoryItem> inventoryItems,
            InventoryActionListener actionListener
    ) {
        this.inventoryItems = inventoryItems;
        this.actionListener = actionListener;
    }

    @NonNull
    @Override
    public InventoryViewHolder onCreateViewHolder(
            @NonNull ViewGroup parent,
            int viewType
    ) {
        // Loads the layout used to display each inventory item.
        View rowView = LayoutInflater
                .from(parent.getContext())
                .inflate(
                        R.layout.inventory_item_row,
                        parent,
                        false
                );
        // Creates a ViewHolder to manage the item's layout.
        return new InventoryViewHolder(rowView);
    }

    @Override
    public void onBindViewHolder(
            @NonNull InventoryViewHolder holder,
            int position
    ) {
        // Gets the inventory item at the current list position.
        InventoryItem item = inventoryItems.get(position);
        // Displays the item's name and quantity.
        holder.itemNameText.setText(item.getName());

        holder.itemQuantityText.setText(
                "Quantity: " + item.getQuantity()
        );
        // Opens the edit function when the Edit button is selected.
        holder.editItemButton.setOnClickListener(
                view -> actionListener.onEditItem(item)
        );
        // Opens the delete function when the Delete button is selected.
        holder.deleteItemButton.setOnClickListener(
                view -> actionListener.onDeleteItem(item)
        );
        // Allows the user to edit an item by selecting its row.
        holder.itemView.setOnClickListener(
                view -> actionListener.onEditItem(item)
        );
    }

    @Override
    public int getItemCount() {
        // Returns the number of inventory items in the list.
        return inventoryItems.size();
    }
    // Replaces the current inventory list with updated database information.
    public void replaceItems(
            ArrayList<InventoryItem> updatedItems
    ) {
        // Removes the items currently stored in the adapter.
        inventoryItems.clear();
        // Adds the updated inventory items to the list.
        inventoryItems.addAll(updatedItems);
        // Refreshes the RecyclerView to display the updated information.
        notifyDataSetChanged();
    }
    // Holds the views used to display and manage a single inventory item.
    static class InventoryViewHolder
            extends RecyclerView.ViewHolder {

        private final TextView itemNameText;
        private final TextView itemQuantityText;
        private final MaterialButton editItemButton;
        private final MaterialButton deleteItemButton;

        public InventoryViewHolder(
                @NonNull View itemView
        ) {
            super(itemView);
            // Connects the item name field to the layout.
            itemNameText =
                    itemView.findViewById(
                            R.id.itemNameText
                    );
            // Connects the item quantity field to the layout.
            itemQuantityText =
                    itemView.findViewById(
                            R.id.itemQuantityText
                    );
            // Connects the Edit button to the layout.
            editItemButton =
                    itemView.findViewById(
                            R.id.editItemButton
                    );
            // Connects the Delete button to the layout.
            deleteItemButton =
                    itemView.findViewById(
                            R.id.deleteItemButton
                    );
        }
    }
}