package com.example.project2;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class LoginActivity extends AppCompatActivity {

    // Holds the username and password entered by the user.
    private EditText usernameInput;
    private EditText passwordInput;

    // Controls the Log In and Create Account buttons.
    private Button loginButton;
    private Button createAccountButton;

    // Gives the Login screen access to the Warehouse Hero database.
    private Database database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Allows the layout to use the full screen.
        EdgeToEdge.enable(this);

        // Loads the Warehouse Hero login screen.
        setContentView(R.layout.activity_main);

        // Connects the Java variables to the views in activity_main.xml.
        usernameInput =
                findViewById(R.id.editTextText);

        passwordInput =
                findViewById(R.id.editTextTextPassword);

        loginButton =
                findViewById(R.id.button);

        createAccountButton =
                findViewById(R.id.button2);

        // Connects the Login screen to the SQLite database.
        database =
                new Database(this);

         //Adds padding around the screen so the layout
         //does not overlap the Android system bars.
        ViewCompat.setOnApplyWindowInsetsListener(
                findViewById(R.id.main),
                (view, windowInsets) -> {

                    Insets systemBars =
                            windowInsets.getInsets(
                                    WindowInsetsCompat.Type.systemBars()
                            );

                    view.setPadding(
                            systemBars.left,
                            systemBars.top,
                            systemBars.right,
                            systemBars.bottom
                    );

                    return windowInsets;
                }
        );


        //LOG IN
        //Checks the username and password against the
        //accounts already saved in the database.
        loginButton.setOnClickListener(view -> {

            // Gets the login information entered by the user.
            String username =
                    usernameInput
                            .getText()
                            .toString()
                            .trim();

            String password =
                    passwordInput
                            .getText()
                            .toString()
                            .trim();

            // Makes sure both fields have information before checking the database.
            if (username.isEmpty() || password.isEmpty()) {

                Toast.makeText(
                        LoginActivity.this,
                        "Please enter a username and password.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Checks the users table for a matching username and password.
            boolean validUser =
                    database.checkUser(
                            username,
                            password
                    );

            if (validUser) {

                // Lets the user know that the login worked.
                Toast.makeText(
                        LoginActivity.this,
                        "Login successful!",
                        Toast.LENGTH_SHORT
                ).show();

                // Opens the Inventory screen after a successful login.
                Intent intent =
                        new Intent(
                                LoginActivity.this,
                                GridActivity.class
                        );

                startActivity(intent);

            } else {

                // Displays an error if the username or password does not match.
                Toast.makeText(
                        LoginActivity.this,
                        "Incorrect username or password.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });


         //CREATE ACCOUNT
         //Saves a new username and password to the database
         //so the user can log in later.

        createAccountButton.setOnClickListener(view -> {

            // Gets the account information entered by the user.
            String username =
                    usernameInput
                            .getText()
                            .toString()
                            .trim();

            String password =
                    passwordInput
                            .getText()
                            .toString()
                            .trim();

            // Prevents the user from creating an account with empty fields.
            if (username.isEmpty() || password.isEmpty()) {

                Toast.makeText(
                        LoginActivity.this,
                        "Please enter a username and password.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Requires the password to contain at least four characters.
            if (password.length() < 4) {

                Toast.makeText(
                        LoginActivity.this,
                        "Password must contain at least 4 characters.",
                        Toast.LENGTH_SHORT
                ).show();

                return;
            }

            // Attempts to save the new account to the users table.
            boolean accountCreated =
                    database.addUser(
                            username,
                            password
                    );

            if (accountCreated) {

                // Lets the user know the new account was saved.
                Toast.makeText(
                        LoginActivity.this,
                        "Account created! You can now log in.",
                        Toast.LENGTH_SHORT
                ).show();
                 //Clears the password field so the user
                 // enters the password again when logging in
                passwordInput.setText("");

            } else {


                 //The username column is unique, so an existing
                 //username cannot be added a second time.
                Toast.makeText(
                        LoginActivity.this,
                        "That username already exists.",
                        Toast.LENGTH_SHORT
                ).show();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Closes the database when the Login screen is destroyed.
        if (database != null) {
            database.close();
        }
    }
}