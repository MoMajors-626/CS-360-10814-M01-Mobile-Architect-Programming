package com.example.project2;

public class InventoryItem {

    // Stores the database ID, item name, and current quantity.
    private final int id;
    private String name;
    private int quantity;

    // Creates an InventoryItem using information pulled from the database.
    public InventoryItem(
            int id,
            String name,
            int quantity
    ) {
        this.id = id;
        this.name = name;
        this.quantity = quantity;
    }

    // Returns the item's unique database ID.
    public int getId() {
        return id;
    }

    // Returns the name of the inventory item.
    public String getName() {
        return name;
    }

    // Returns the current quantity of the item.
    public int getQuantity() {
        return quantity;
    }

    // Updates the item's name.
    public void setName(String name) {
        this.name = name;
    }

    // Updates the item's quantity.
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}