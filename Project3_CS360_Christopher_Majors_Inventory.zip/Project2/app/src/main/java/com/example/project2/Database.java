package com.example.project2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class Database extends SQLiteOpenHelper {

    // Name and version of the Warehouse Hero database.
    private static final String DATABASE_NAME = "warehouse_hero.db";
    private static final int DATABASE_VERSION = 1;

    // Information used for the users table.
    private static final String TABLE_USERS = "users";
    private static final String USER_ID = "id";
    private static final String USERNAME = "username";
    private static final String PASSWORD = "password";

    // Information used for the inventory table.
    private static final String TABLE_INVENTORY = "inventory";
    private static final String ITEM_ID = "id";
    private static final String ITEM_NAME = "item_name";
    private static final String ITEM_QUANTITY = "quantity";

    // Connects the app to the Warehouse Hero SQLite database.
    public Database(Context context) {
        super(
                context,
                DATABASE_NAME,
                null,
                DATABASE_VERSION
        );
    }

    @Override
    public void onCreate(SQLiteDatabase database) {

        // Creates the users table so account information can be saved.
        String createUsersTable =
                "CREATE TABLE " + TABLE_USERS + " (" +
                        USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        USERNAME + " TEXT UNIQUE NOT NULL, " +
                        PASSWORD + " TEXT NOT NULL)";

        // Creates the inventory table for item names and quantities.
        String createInventoryTable =
                "CREATE TABLE " + TABLE_INVENTORY + " (" +
                        ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        ITEM_NAME + " TEXT NOT NULL, " +
                        ITEM_QUANTITY + " INTEGER NOT NULL)";

        // Creates both tables the first time the database is opened.
        database.execSQL(createUsersTable);
        database.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(
            SQLiteDatabase database,
            int oldVersion,
            int newVersion
    ) {

        // Recreates the tables if I change the database version later.
        database.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_USERS
        );

        database.execSQL(
                "DROP TABLE IF EXISTS " + TABLE_INVENTORY
        );

        onCreate(database);
    }

    /*
     * USER ACCOUNT FUNCTIONS
     */

    // Saves a new username and password when a user creates an account.
    public boolean addUser(
            String username,
            String password
    ) {

        SQLiteDatabase database =
                getWritableDatabase();

        // Stores the username and password before adding them to the table.
        ContentValues values =
                new ContentValues();

        values.put(USERNAME, username);
        values.put(PASSWORD, password);

        // Attempts to save the account to the users table.
        long result = database.insert(
                TABLE_USERS,
                null,
                values
        );

        // A result of -1 means the account could not be saved.
        return result != -1;
    }

    // Checks the database to see if the username and password match.
    public boolean checkUser(
            String username,
            String password
    ) {

        SQLiteDatabase database =
                getReadableDatabase();

        // Uses placeholders so the username and password
        // are passed separately from the SQL query.
        String selection =
                USERNAME + " = ? AND " +
                        PASSWORD + " = ?";

        String[] selectionArguments = {
                username,
                password
        };

        // Searches for one account that matches both values.
        Cursor cursor = database.query(
                TABLE_USERS,
                new String[]{USER_ID},
                selection,
                selectionArguments,
                null,
                null,
                null,
                "1"
        );

        // If a matching row exists, the login information is valid.
        boolean userExists =
                cursor.moveToFirst();

        // Closes the cursor after the database search is finished.
        cursor.close();

        return userExists;
    }

    /*
     * INVENTORY FUNCTIONS
     */

    // CREATE: Adds a new item and quantity to the inventory database.
    public boolean addItem(
            String itemName,
            int quantity
    ) {

        SQLiteDatabase database =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(ITEM_NAME, itemName);
        values.put(ITEM_QUANTITY, quantity);

        // Attempts to save the new inventory item.
        long result = database.insert(
                TABLE_INVENTORY,
                null,
                values
        );

        return result != -1;
    }

    // READ: Gets all inventory items so they can be shown on the grid screen.
    public ArrayList<InventoryItem> getAllItems() {

        // This list will hold the inventory items read from SQLite.
        ArrayList<InventoryItem> items =
                new ArrayList<>();

        SQLiteDatabase database =
                getReadableDatabase();

        // Reads the ID, name, and quantity for every inventory item.
        Cursor cursor = database.query(
                TABLE_INVENTORY,
                new String[]{
                        ITEM_ID,
                        ITEM_NAME,
                        ITEM_QUANTITY
                },
                null,
                null,
                null,
                null,

                // Keeps the inventory list organized alphabetically.
                ITEM_NAME + " ASC"
        );

        // Gets the location of each column in the database results.
        int idColumn =
                cursor.getColumnIndexOrThrow(
                        ITEM_ID
                );

        int nameColumn =
                cursor.getColumnIndexOrThrow(
                        ITEM_NAME
                );

        int quantityColumn =
                cursor.getColumnIndexOrThrow(
                        ITEM_QUANTITY
                );

        // Goes through each database row and creates an InventoryItem.
        while (cursor.moveToNext()) {

            int id =
                    cursor.getInt(idColumn);

            String name =
                    cursor.getString(nameColumn);

            int quantity =
                    cursor.getInt(quantityColumn);

            InventoryItem inventoryItem =
                    new InventoryItem(
                            id,
                            name,
                            quantity
                    );

            // Adds the item to the list that will be shown on screen.
            items.add(inventoryItem);
        }

        // Closes the cursor after all inventory information has been read.
        cursor.close();

        return items;
    }

    // UPDATE: Changes the name or quantity of an existing inventory item.
    public boolean updateItem(
            int id,
            String itemName,
            int quantity
    ) {

        SQLiteDatabase database =
                getWritableDatabase();

        ContentValues values =
                new ContentValues();

        values.put(ITEM_NAME, itemName);
        values.put(ITEM_QUANTITY, quantity);

        // Updates only the inventory item with the matching ID.
        int rowsUpdated = database.update(
                TABLE_INVENTORY,
                values,
                ITEM_ID + " = ?",
                new String[]{
                        String.valueOf(id)
                }
        );

        // If at least one row changed, the update worked.
        return rowsUpdated > 0;
    }

    // DELETE: Removes an inventory item using its database ID.
    public boolean deleteItem(int id) {

        SQLiteDatabase database =
                getWritableDatabase();

        // Deletes only the item with the matching ID.
        int rowsDeleted = database.delete(
                TABLE_INVENTORY,
                ITEM_ID + " = ?",
                new String[]{
                        String.valueOf(id)
                }
        );

        // If at least one row was deleted, the delete worked.
        return rowsDeleted > 0;
    }
}